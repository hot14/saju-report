#!/usr/bin/env node
/** HSH P600 사전점검 v3.1 — 체인 실행 전 환경·파일·스킬 가용성 확인. exit 0이면 실행 가능 */
import fs from "node:fs";
import { execSync } from "node:child_process";

const KIT = process.argv[2] || new URL("..", import.meta.url).pathname.replace(/\/$/, "");
const HOME = process.env.HOME;
let fails = 0, warns = 0;
const ok = m => console.log("✓", m);
const bad = m => { console.error("✗", m); fails++; };
const warn = m => { console.warn("⚠", m); warns++; };

// 1. 파일 존재
for (const f of ["01-공통계약-CC.md","runner/MANIFEST.json","state/00-input.json"]) {
  fs.existsSync(`${KIT}/${f}`) ? ok(`${f}`) : bad(`${f} 없음`);
}
// 2. 프롬프트 15종
const prompts = fs.existsSync(`${KIT}/prompts`) ? fs.readdirSync(`${KIT}/prompts`) : [];
prompts.length >= 15 ? ok(`prompts ${prompts.length}개`) : bad(`prompts 부족 (${prompts.length}/15)`);
// 3. 원문 요청 채워졌는지
try {
  const input = JSON.parse(fs.readFileSync(`${KIT}/state/00-input.json`,"utf8"));
  input.user_request.length > 200 ? ok("user_request 원문 주입됨") : bad("user_request가 플레이스홀더 상태");
} catch { bad("00-input.json 파싱 실패"); }
// 4. 스킬 가용성
const skills = ["fluent-korean","humanize-korean","stop-slop","korean-quality-gate"];
for (const s of skills) fs.existsSync(`${HOME}/.aside/u/0/skills/user/${s}/SKILL.md`) ? ok(`스킬 ${s}`) : warn(`스킬 ${s} 없음 (해당 훅 건너뜀)`);
// 5. 법령 CLI
try { execSync(`node ${HOME}/.aside/u/0/tools/korean-law-mcp/build/cli.js --help 2>&1 | head -1`, {stdio:"pipe"}); ok("korean-law-mcp CLI"); }
catch { warn("korean-law-mcp CLI 응답 없음 — P606/P611 법령 조회는 2차 문서로 강등됨"); }
// 6. 검증기 자체
fs.existsSync(`${KIT}/runner/validate-handoff.mjs`) ? ok("handoff 검증기") : bad("검증기 없음");
// 7. 아카이브 레지스트라
fs.existsSync(`${HOME}/.aside/u/0/skills/user/report-archive/scripts/archive.mjs`) ? ok("report-archive 레지스트라") : warn("아카이브 스킬 없음 — P612 수동 등록 필요");

console.log(`\n결과: ${fails} 실패 / ${warns} 경고`);
process.exit(fails ? 1 : 0);
