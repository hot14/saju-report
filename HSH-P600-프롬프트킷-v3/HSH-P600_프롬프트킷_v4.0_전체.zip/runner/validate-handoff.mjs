#!/usr/bin/env node
/**
 * HSH P600 handoff 검증기 v3.1
 * 용법:
 *   node validate-handoff.mjs <P6xx-out.json> [--id P601]
 *   node validate-handoff.mjs <응답원문.md>   (```handoff``` 펜스에서 자동 추출)
 * 검증: JSON 파싱 → 필수 필드 존재 → 배열 최소 개수 → null 금지 → inheritance_resolved 존재
 * exit 0 = 통과, 1 = 반려 (결함 목록 출력)
 */
import fs from "node:fs";

// 프롬프트별 최소 스키마 (v3.1). required: [필드, (배열최소개수|0)]
const SCHEMAS = {
  P600: {required:[["schema_version"],["project"],["goal_tree"],["constraints"],["tracks",6],["kill_rules",6],["decision_points",3],["l1_specs"],["uncertainties",8],["chain_budget"],["승계보강",0],["inheritance_resolved"]]},
  P601: {required:[["schema_version"],["base_date"],["trends",10],["emerging",5],["dead",4],["regional"],["consensus",3],["debates",2],["stale_list",0],["method"],["승계보강",0],["inheritance_resolved"]]},
  P602: {required:[["schema_version"],["cases",12],["patterns",5],["failure_modes",5],["unit_price_table",10],["base_rates",2],["bias_statement"],["승계보강",0],["inheritance_resolved"]]},
  P603: {required:[["schema_version"],["benchmarks",22],["cat_structure"],["whitespaces",5],["korea_notes"],["price_changes",0],["승계보강",0],["inheritance_resolved"]]},
  P604: {required:[["schema_version"],["channels",9],["policy_deadlines",0],["matrix"],["combos",3],["launch_seq",4],["승계보강",0],["inheritance_resolved"]]},
  P605: {required:[["schema_version"],["models",6],["stack",7],["standard_arch"],["risks",4],["roadmap",3],["승계보강",0],["inheritance_resolved"]]},
  P606: {required:[["schema_version"],["checklist",8],["tax_scenarios"],["overseas",4],["disclosure",3],["korea_platforms"],["reality_check"],["precedents",5],["law_lookups",8],["승계보강",0],["inheritance_resolved"]]},
  G1:   {required:[["verdict"],["cross_matrix",6],["demotions",0],["hallucinations",0],["schema_check",6],["independence"],["rerun_list",0],["clean_package"],["summary"]]},
  P607: {required:[["schema_version"],["scoring"],["portfolio",2],["excluded",0],["synergy",3],["differentiation",4],["products",5],["gtm",4],["kill_rules_v2",0],["dp1"],["승계보강",0],["inheritance_resolved"]]},
  P608: {required:[["schema_version"],["fx"],["scenarios"],["unit_economics"],["cost_model"],["derived"],["after_tax"],["backcast",3],["sensitivity"],["dp2"],["승계보강",0],["inheritance_resolved"]]},
  P609: {required:[["schema_version"],["phases",5],["daily",30],["weekly",24],["gates",7],["automation",4],["safeguards",5],["kpi"],["starter_kit"],["승계보강",0],["inheritance_resolved"]]},
  P610: {required:[["schema_version"],["data_version"],["charts",13],["interactions"],["ia"],["deref_report"],["insights",8],["quality_gate_report"],["승계보강",0],["inheritance_resolved"]]},
  P611: {required:[["g2_verdict"],["cross_checks",5],["bias_scan",6],["law_recheck_log",0],["corrections",0],["unverified",0],["rerun_list",0],["trend"],["summary"]]},
  P612: {required:[["report"],["quality_gate_final"],["archive"],["dp_dashboard",3],["roadmap_branches"],["chain_log",14],["chain_kpi"],["next_chain_recommendation"],["승계보강",0],["inheritance_resolved"]]},
  P613: {required:[["schema_version"],["cycle"],["gate_results",0],["scenario_decision"],["trend_delta",0],["kpi_injection"],["anomalies",0],["next_actions"],["승계보강",0],["inheritance_resolved"]]},
};

const [,, target, flag, val] = process.argv;
if (!target) { console.error("용법: node validate-handoff.mjs <파일> [--id P601]"); process.exit(1); }

let raw = fs.readFileSync(target, "utf8");
let id = val;
// handoff 펜스 자동 추출 (원문 마크다운인 경우)
const fence = raw.match(/```handoff\s*([\s\S]*?)```/);
if (fence) { raw = fence[1]; if (!id) { const m = target.match(/(P6\d\d|G1)/); if (m) id = m[1]; } }
if (!id) id = "P600";

let obj, errs = [];
try { obj = JSON.parse(raw); } catch (e) { console.error("✗ JSON 파싱 실패:", e.message); process.exit(1); }

const schema = SCHEMAS[id];
if (!schema) { console.error(`✗ 알 수 없는 프롬프트 ID: ${id}`); process.exit(1); }

for (const [field, min] of schema.required) {
  const v = obj[field];
  if (v === undefined) { errs.push(`필수 필드 누락: ${field}`); continue; }
  if (v === null) { errs.push(`null 금지 위반: ${field} (미확정은 문자열 "미확인")`); continue; }
  if (Array.isArray(v) && min > 0 && v.length < min) errs.push(`배열 최소 미달: ${field} ${v.length}/${min}`);
}
// 깊은 null 스캔 (1레벨)
function nullScan(o, path) {
  if (o === null) errs.push(`null 값: ${path}`);
  else if (typeof o === "object" && !Array.isArray(o)) for (const k in o) nullScan(o[k], `${path}.${k}`);
}
nullScan(obj, "$");

if (errs.length) { console.error(`✗ ${id} 스키마 반려 (${errs.length}건)`); errs.forEach(e => console.error("  -", e)); process.exit(1); }
console.log(`✓ ${id} handoff 통과 (필수 ${schema.required.length}개 필드, 배열 최소 전부 충족)`);
