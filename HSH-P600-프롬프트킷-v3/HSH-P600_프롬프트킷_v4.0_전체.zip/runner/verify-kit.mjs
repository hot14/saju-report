#!/usr/bin/env node
/** HSH P600 킷 전수 검증기 v4.0 — 실행 전 GO/NO-GO 판정 */
import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

const KIT = process.argv[2] || path.resolve(import.meta.dirname, "..");
let pass = 0, fail = 0;
const ok = t => { console.log("  ✓", t); pass++; };
const bad = t => { console.log("  ✗", t); fail++; };
const section = t => console.log("\n■", t);

// ── 1. 필수 파일 존재 ──
section("1. 파일 인벤토리");
const need = ["README.md","00-아키텍처-v3.md","01-공통계약-CC.md","02-비판분석-v3.md","03-스킬통합명세.md",
 "runner/MANIFEST.json","runner/RUN-가이드.md","runner/validate-handoff.mjs","runner/preflight.mjs",
 "state/00-input.json","state/chain-state.json","state/dp-responses.json","state/measured-kpi.json"];
for (const f of need) fs.existsSync(path.join(KIT,f)) ? ok(f) : bad(f+" 없음");
const prompts = fs.readdirSync(path.join(KIT,"prompts")).filter(f=>f.endsWith(".md"));
prompts.length===15 ? ok(`prompts 15종 (${prompts.length})`) : bad(`prompts ${prompts.length}/15`);

// ── 2. 프롬프트 구조 전수 ──
section("2. 프롬프트 구조 (15종 전수)");
const mustHave = ["[페르소나]","[출력 문서 골격] 또는 골격","품질 게이트","실패 프로토콜"];
for (const f of prompts) {
  const s = fs.readFileSync(path.join(KIT,"prompts",f),"utf8");
  const errs = [];
  if (!/^version: 4\.0/m.test(s)) errs.push("version 4.0 헤더");
  if (!s.includes("[페르소나]")) errs.push("페르소나");
  if (!/품질 게이트/.test(s)) errs.push("품질 게이트");
  if (!/실패 프로토콜/.test(s)) errs.push("실패 프로토콜");
  if (!/\[handoff 스키마\]|handoff 스키마/.test(s)) errs.push("handoff 스키마");
  const isGate = f.startsWith("G1");
  if (!isGate && !s.includes("[v4.0 고도화 모듈]")) errs.push("v4.0 고도화 모듈");
  if (isGate && !s.includes("[v4.0 고도화 모듈]")) errs.push("v4.0 고도화 모듈(게이트)");
  errs.length===0 ? ok(f) : bad(f+" 누락: "+errs.join(", "));
}

// ── 3. JSON 무결성 ──
section("3. JSON 파싱");
for (const f of ["runner/MANIFEST.json","state/00-input.json","state/chain-state.json","state/dp-responses.json","state/measured-kpi.json"]) {
  try { JSON.parse(fs.readFileSync(path.join(KIT,f),"utf8")); ok(f); } catch(e){ bad(f+" 파싱 실패: "+e.message); }
}

// ── 4. MANIFEST ↔ 파일 교차참조 ──
section("4. 교차참조");
const man = JSON.parse(fs.readFileSync(path.join(KIT,"runner/MANIFEST.json"),"utf8"));
for (const [id,rel] of Object.entries(man.prompt_files)) {
  fs.existsSync(path.join(KIT,rel)) ? ok(`${id} → ${rel}`) : bad(`${id} 경로 없음: ${rel}`);
}
man.version==="4.0" ? ok("MANIFEST version 4.0") : bad("MANIFEST 버전 불일치");
// 스키마 검증기가 15종 ID 지원하는지
const validator = fs.readFileSync(path.join(KIT,"runner/validate-handoff.mjs"),"utf8");
const ids = ["P600","P601","P602","P603","P604","P605","P606","G1","P607","P608","P609","P610","P611","P612","P613"];
const missing = ids.filter(id=>!new RegExp(`^\\s*${id}:\\s*\\{required`, "m").test(validator));
missing.length===0 ? ok("검증기 15종 스키마 전부 지원") : bad("검증기 미지원: "+missing.join(","));

// ── 5. 계약 문서 완결성 ──
section("5. 공통 계약");
const cc = fs.readFileSync(path.join(KIT,"01-공통계약-CC.md"),"utf8");
const ccIds = [...Array(17)].map((_,i)=>`CC-${i+1}`);
const ccMissing = ccIds.filter(c=>!cc.includes(c));
ccMissing.length===0 ? ok("CC-1 ~ CC-17 전부 존재") : bad("CC 누락: "+ccMissing.join(","));
["inheritance_resolved","심화 사다리","자기반박"].every(k=>cc.includes(k)) ? ok("고도화 계약(15~17) 본문 확인") : bad("고도화 계약 본문 불완전");

// ── 6. 입력값 준비 ──
section("6. 실행 입력");
const input = JSON.parse(fs.readFileSync(path.join(KIT,"state/00-input.json"),"utf8"));
input.user_request.length>500 ? ok(`user_request ${input.user_request.length}자 주입됨`) : bad("user_request 미주입");
input.budget_ceiling.total===3000000 ? ok("예산 300만 설정") : bad("예산 설정 오류");
input.prior_artifacts.length>=3 ? ok(`선행 감사 ${input.prior_artifacts.length}건`) : bad("선행 감사 부족");

// ── 7. 런타임 의존성 실측 ──
section("7. 런타임 의존성");
try { execSync(`node "${KIT}/runner/validate-handoff.mjs" --help 2>&1 || true`, {stdio:"pipe"}); ok("validate-handoff.mjs 실행 가능"); } catch { bad("검증기 실행 불가"); }
try { const r = execSync(`node "${KIT}/runner/preflight.mjs" "${KIT}" 2>&1 | tail -1`, {stdio:"pipe",encoding:"utf8"}); r.includes("0 실패") ? ok("preflight 0 실패") : bad("preflight: "+r.trim()); } catch(e){ bad("preflight 실행 오류"); }
// 법령 CLI 실쿼리 (부가세법 검색만)
try {
  const out = execSync(`export LAW_OC=test; node ~/.aside/u/0/tools/korean-law-mcp/build/cli.js search_law --query "부가가치세법" 2>&1 | head -5`, {stdio:"pipe",encoding:"utf8",timeout:30000});
  out.length>20 ? ok("korean-law-mcp 실쿼리 응답 ("+out.trim().split("\n")[0].slice(0,40)+"...)") : bad("법령 CLI 빈 응답");
} catch(e){ bad("법령 CLI 실패: "+String(e.message).slice(0,60)); }

// ── 8. 검증기 스키마 스모크 (15종 전부) ──
section("8. handoff 검증기 15종 스모크");
const tmp = "/tmp/hsh-smoke";
fs.mkdirSync(tmp,{recursive:true});
const min = n => Array.from({length:n},()=>1);
const payload = (id)=>{
  const o = {schema_version:"4.0", inheritance_resolved:false, "승계보강":[]};
  const fill = {P600:{project:{},goal_tree:{},constraints:{},tracks:min(6),kill_rules:min(6),decision_points:min(3),l1_specs:{},uncertainties:min(8),chain_budget:{}},
   P601:{base_date:"2026-08-23",trends:min(10),emerging:min(5),dead:min(4),regional:{},consensus:min(3),debates:min(2),stale_list:[],method:{}},
   P602:{cases:min(12),patterns:min(5),failure_modes:min(5),unit_price_table:min(10),base_rates:min(2),bias_statement:"x"},
   P603:{benchmarks:min(22),cat_structure:{},whitespaces:min(5),korea_notes:"x",price_changes:[]},
   P604:{channels:min(9),policy_deadlines:[],matrix:{},combos:min(3),launch_seq:min(4)},
   P605:{models:min(6),stack:min(7),standard_arch:{},risks:min(4),roadmap:min(3)},
   P606:{checklist:min(8),tax_scenarios:{},overseas:min(4),disclosure:min(3),korea_platforms:{},reality_check:{},precedents:min(5),law_lookups:min(8)},
   G1:{verdict:"PASS",cross_matrix:min(6),demotions:[],hallucinations:[],schema_check:min(6),independence:{},rerun_list:[],clean_package:{},summary:"x"},
   P607:{scoring:{},portfolio:min(2),excluded:[],synergy:min(3),differentiation:min(4),products:min(5),gtm:min(4),kill_rules_v2:[],dp1:{}},
   P608:{fx:{},scenarios:{},unit_economics:{},cost_model:{},derived:{},after_tax:{},backcast:min(3),sensitivity:{},dp2:{}},
   P609:{phases:min(5),daily:min(30),weekly:min(24),gates:min(7),automation:min(4),safeguards:min(5),kpi:{},starter_kit:{}},
   P610:{data_version:"4.0",charts:min(13),interactions:{},ia:{},deref_report:{},insights:min(8),quality_gate_report:{}},
   P611:{g2_verdict:"PASS",cross_checks:min(5),bias_scan:min(6),law_recheck_log:[],corrections:[],unverified:[],rerun_list:[],trend:{},summary:"x"},
   P612:{report:{},quality_gate_final:{},archive:{},dp_dashboard:min(3),roadmap_branches:{},chain_log:min(14),chain_kpi:{},next_chain_recommendation:"x"},
   P613:{cycle:{},gate_results:[],scenario_decision:{},trend_delta:[],kpi_injection:{},anomalies:[],next_actions:min(3)}};
  return Object.assign(o, fill[id]||{});
};
let smokeFail = 0;
for (const id of ids) {
  const f = path.join(tmp, id+".json");
  fs.writeFileSync(f, JSON.stringify(payload(id)));
  try {
    execSync(`node "${KIT}/runner/validate-handoff.mjs" "${f}" --id ${id}`, {stdio:"pipe"});
    ok(`${id} 스키마 통과`);
  } catch(e){ bad(`${id} 스키마 반려`); smokeFail++; }
}
// 반려판정 테스트 (P601에서 trends 3개 → 반려되어야 함)
fs.writeFileSync(path.join(tmp,"bad.json"), JSON.stringify({...payload("P601"), trends:[1,2,3]}));
try { execSync(`node "${KIT}/runner/validate-handoff.mjs" "${path.join(tmp,"bad.json")}" --id P601`, {stdio:"pipe"}); bad("반례 테스트: 미달값을 통과시킴(검증기 결함)"); }
catch { ok("반례 테스트: 미달값 정상 반려"); }

fs.rmSync(tmp,{recursive:true,force:true});
console.log(`\n════════ 종합: ${pass} 통과 / ${fail} 실패 ════════`);
console.log(fail===0 ? "판정: GO — 체인 실행 가능" : "판정: NO-GO — 실패 항목 수정 필요");
process.exit(fail===0?0:1);
